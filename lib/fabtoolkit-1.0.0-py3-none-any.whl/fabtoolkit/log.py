import logging


class ConsoleFormatter(logging.Formatter):
    """Custom logging formatter for console output with ANSI color codes."""

    grey = "\x1b[38;20m"
    bold_white = "\x1b[1;37m"
    yellow = "\x1b[33;20m"
    red = "\x1b[31;20m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    MESSAGE_FORMAT = " %(asctime)s - %(message)s"
    DATE_FORMAT = "%H:%M:%S"

    def __init__(self):
        super().__init__()
        self.FORMATS = {
            logging.DEBUG: f"{self.grey}[DEBUG]{self.MESSAGE_FORMAT}{self.reset}",
            logging.INFO: f"{self.bold_white}[INFO]{self.MESSAGE_FORMAT}{self.reset}",
            logging.WARNING: f"{self.yellow}[WARNING]{self.MESSAGE_FORMAT}{self.reset}",
            logging.ERROR: f"{self.red}[ERROR]{self.MESSAGE_FORMAT}{self.reset}",
            logging.CRITICAL: f"{self.bold_red}[CRITICAL]{self.MESSAGE_FORMAT}{self.reset}",
        }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt=self.DATE_FORMAT)
        return formatter.format(record)